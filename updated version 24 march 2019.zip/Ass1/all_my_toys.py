class allMyToys:
    def __init__(self, new_name):
        self.name = new_name

