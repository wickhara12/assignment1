class View:
    @staticmethod
    def newline():
        return '\n'

    @staticmethod
    def tab():
        return '    '
