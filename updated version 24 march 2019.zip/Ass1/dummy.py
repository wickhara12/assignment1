class dummy:
    def __init__(self, new_dummy<|--_toy_box, new_name, new_color, new_cost):
        self.dummy<|--_toy_box = new_dummy<|--_toy_box
        self.name = new_name
        self.color = new_color
        self.cost = new_cost

    def addToy(self):
        pass

