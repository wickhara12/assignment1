"""this is Simon England code for task 8"""
class FileHandler:

    @staticmethod
    def write_to_file(new_file_name, file_content):
        try:
            with open(new_file_name + '.py', 'w') as f:
                f.write(file_content)
        except Exception as e:
            print(e)


def load_from_file(file_name):
    try:
        with open(file_name, 'r') as f:
            return f.readlines()
    except FileNotFoundError:
        print("Error - File not found")
    except FileExistsError:
        print("Error")
    except Exception as e:
        print(e)
