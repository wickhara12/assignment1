class ToyBox:
    def __init__(self, new_all_my_toys, new_name):
        self.all_my_toys = new_all_my_toys
        self.name = new_name

    def getToys(self):
        pass

    def sortToys(self):
        pass

